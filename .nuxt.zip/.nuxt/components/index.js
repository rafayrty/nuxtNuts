export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Cart } from '../..\\components\\Cart\\Cart.vue'
export { default as Footer } from '../..\\components\\Footer\\Footer.vue'
export { default as HeaderMain } from '../..\\components\\Header\\HeaderMain.vue'
export { default as DesktopMenu } from '../..\\components\\Header\\DesktopMenu\\DesktopMenu.vue'
export { default as Forgot } from '../..\\components\\Header\\Logins\\Forgot.vue'
export { default as Login } from '../..\\components\\Header\\Logins\\Login.vue'
export { default as Main } from '../..\\components\\Header\\Logins\\Main.vue'
export { default as Register } from '../..\\components\\Header\\Logins\\Register.vue'
export { default as MobileMenu } from '../..\\components\\Header\\MobileMenu\\MobileMenu.vue'

export const LazyLogo = import('../..\\components\\Logo.vue' /* webpackChunkName: "components/logo" */).then(c => c.default || c)
export const LazyCart = import('../..\\components\\Cart\\Cart.vue' /* webpackChunkName: "components/cart" */).then(c => c.default || c)
export const LazyFooter = import('../..\\components\\Footer\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => c.default || c)
export const LazyHeaderMain = import('../..\\components\\Header\\HeaderMain.vue' /* webpackChunkName: "components/header-main" */).then(c => c.default || c)
export const LazyDesktopMenu = import('../..\\components\\Header\\DesktopMenu\\DesktopMenu.vue' /* webpackChunkName: "components/desktop-menu" */).then(c => c.default || c)
export const LazyForgot = import('../..\\components\\Header\\Logins\\Forgot.vue' /* webpackChunkName: "components/forgot" */).then(c => c.default || c)
export const LazyLogin = import('../..\\components\\Header\\Logins\\Login.vue' /* webpackChunkName: "components/login" */).then(c => c.default || c)
export const LazyMain = import('../..\\components\\Header\\Logins\\Main.vue' /* webpackChunkName: "components/main" */).then(c => c.default || c)
export const LazyRegister = import('../..\\components\\Header\\Logins\\Register.vue' /* webpackChunkName: "components/register" */).then(c => c.default || c)
export const LazyMobileMenu = import('../..\\components\\Header\\MobileMenu\\MobileMenu.vue' /* webpackChunkName: "components/mobile-menu" */).then(c => c.default || c)
