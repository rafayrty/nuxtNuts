import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3914bf89 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _2072b8fa = () => interopDefault(import('..\\pages\\basket\\index.vue' /* webpackChunkName: "pages/basket/index" */))
const _d10599d8 = () => interopDefault(import('..\\pages\\product\\_slug.vue' /* webpackChunkName: "pages/product/_slug" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/ar",
    component: _3914bf89,
    name: "index___ar"
  }, {
    path: "/basket",
    component: _2072b8fa,
    name: "basket___he"
  }, {
    path: "/en",
    component: _3914bf89,
    name: "index___en"
  }, {
    path: "/ar/basket",
    component: _2072b8fa,
    name: "basket___ar"
  }, {
    path: "/en/basket",
    component: _2072b8fa,
    name: "basket___en"
  }, {
    path: "/ar/product/:slug?",
    component: _d10599d8,
    name: "product-slug___ar"
  }, {
    path: "/en/product/:slug?",
    component: _d10599d8,
    name: "product-slug___en"
  }, {
    path: "/product/:slug?",
    component: _d10599d8,
    name: "product-slug___he"
  }, {
    path: "/",
    component: _3914bf89,
    name: "index___he"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
