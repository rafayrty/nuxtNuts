import Vue from 'vue';
import { SharedElementDirective, NuxtSharedElementRouteGuard } from 'v-shared-element';

Vue.use(SharedElementDirective, {"easing":"ease-in-out"});

export default NuxtSharedElementRouteGuard;
