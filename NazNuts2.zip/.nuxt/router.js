import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from '@nuxt/ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _3914bf89 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _2072b8fa = () => interopDefault(import('..\\pages\\basket\\index.vue' /* webpackChunkName: "pages/basket/index" */))
const _017a27e7 = () => interopDefault(import('..\\pages\\blog\\index.vue' /* webpackChunkName: "pages/blog/index" */))
const _53473cae = () => interopDefault(import('..\\pages\\cart\\index.vue' /* webpackChunkName: "pages/cart/index" */))
const _38339817 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _1140d206 = () => interopDefault(import('..\\pages\\fresh\\index.vue' /* webpackChunkName: "pages/fresh/index" */))
const _739f1661 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _00eb3b02 = () => interopDefault(import('..\\pages\\account\\address\\index.vue' /* webpackChunkName: "pages/account/address/index" */))
const _c46510ee = () => interopDefault(import('..\\pages\\account\\orders.vue' /* webpackChunkName: "pages/account/orders" */))
const _db171696 = () => interopDefault(import('..\\pages\\account\\profile.vue' /* webpackChunkName: "pages/account/profile" */))
const _4d93a00b = () => interopDefault(import('..\\pages\\cart\\address.vue' /* webpackChunkName: "pages/cart/address" */))
const _4b8b60a9 = () => interopDefault(import('..\\pages\\cart\\gift.vue' /* webpackChunkName: "pages/cart/gift" */))
const _43dadd1d = () => interopDefault(import('..\\pages\\cart\\payment.vue' /* webpackChunkName: "pages/cart/payment" */))
const _5065ead0 = () => interopDefault(import('..\\pages\\account\\address\\new.vue' /* webpackChunkName: "pages/account/address/new" */))
const _bad8f4c0 = () => interopDefault(import('..\\pages\\account\\address\\edit\\_id.vue' /* webpackChunkName: "pages/account/address/edit/_id" */))
const _0078f2c2 = () => interopDefault(import('..\\pages\\blog\\_slug.vue' /* webpackChunkName: "pages/blog/_slug" */))
const _d10599d8 = () => interopDefault(import('..\\pages\\product\\_slug.vue' /* webpackChunkName: "pages/product/_slug" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/ar",
    component: _3914bf89,
    name: "index___ar"
  }, {
    path: "/basket",
    component: _2072b8fa,
    name: "basket___he"
  }, {
    path: "/blog",
    component: _017a27e7,
    name: "blog___he"
  }, {
    path: "/cart",
    component: _53473cae,
    name: "cart___he"
  }, {
    path: "/contact",
    component: _38339817,
    name: "contact___he"
  }, {
    path: "/en",
    component: _3914bf89,
    name: "index___en"
  }, {
    path: "/fresh",
    component: _1140d206,
    name: "fresh___he"
  }, {
    path: "/search",
    component: _739f1661,
    name: "search___he"
  }, {
    path: "/account/address",
    component: _00eb3b02,
    name: "account-address___he"
  }, {
    path: "/account/orders",
    component: _c46510ee,
    name: "account-orders___he"
  }, {
    path: "/account/profile",
    component: _db171696,
    name: "account-profile___he"
  }, {
    path: "/ar/basket",
    component: _2072b8fa,
    name: "basket___ar"
  }, {
    path: "/ar/blog",
    component: _017a27e7,
    name: "blog___ar"
  }, {
    path: "/ar/cart",
    component: _53473cae,
    name: "cart___ar"
  }, {
    path: "/ar/contact",
    component: _38339817,
    name: "contact___ar"
  }, {
    path: "/ar/fresh",
    component: _1140d206,
    name: "fresh___ar"
  }, {
    path: "/ar/search",
    component: _739f1661,
    name: "search___ar"
  }, {
    path: "/cart/address",
    component: _4d93a00b,
    name: "cart-address___he"
  }, {
    path: "/cart/gift",
    component: _4b8b60a9,
    name: "cart-gift___he"
  }, {
    path: "/cart/payment",
    component: _43dadd1d,
    name: "cart-payment___he"
  }, {
    path: "/en/basket",
    component: _2072b8fa,
    name: "basket___en"
  }, {
    path: "/en/blog",
    component: _017a27e7,
    name: "blog___en"
  }, {
    path: "/en/cart",
    component: _53473cae,
    name: "cart___en"
  }, {
    path: "/en/contact",
    component: _38339817,
    name: "contact___en"
  }, {
    path: "/en/fresh",
    component: _1140d206,
    name: "fresh___en"
  }, {
    path: "/en/search",
    component: _739f1661,
    name: "search___en"
  }, {
    path: "/account/address/new",
    component: _5065ead0,
    name: "account-address-new___he"
  }, {
    path: "/ar/account/address",
    component: _00eb3b02,
    name: "account-address___ar"
  }, {
    path: "/ar/account/orders",
    component: _c46510ee,
    name: "account-orders___ar"
  }, {
    path: "/ar/account/profile",
    component: _db171696,
    name: "account-profile___ar"
  }, {
    path: "/ar/cart/address",
    component: _4d93a00b,
    name: "cart-address___ar"
  }, {
    path: "/ar/cart/gift",
    component: _4b8b60a9,
    name: "cart-gift___ar"
  }, {
    path: "/ar/cart/payment",
    component: _43dadd1d,
    name: "cart-payment___ar"
  }, {
    path: "/en/account/address",
    component: _00eb3b02,
    name: "account-address___en"
  }, {
    path: "/en/account/orders",
    component: _c46510ee,
    name: "account-orders___en"
  }, {
    path: "/en/account/profile",
    component: _db171696,
    name: "account-profile___en"
  }, {
    path: "/en/cart/address",
    component: _4d93a00b,
    name: "cart-address___en"
  }, {
    path: "/en/cart/gift",
    component: _4b8b60a9,
    name: "cart-gift___en"
  }, {
    path: "/en/cart/payment",
    component: _43dadd1d,
    name: "cart-payment___en"
  }, {
    path: "/ar/account/address/new",
    component: _5065ead0,
    name: "account-address-new___ar"
  }, {
    path: "/en/account/address/new",
    component: _5065ead0,
    name: "account-address-new___en"
  }, {
    path: "/ar/account/address/edit/:id?",
    component: _bad8f4c0,
    name: "account-address-edit-id___ar"
  }, {
    path: "/en/account/address/edit/:id?",
    component: _bad8f4c0,
    name: "account-address-edit-id___en"
  }, {
    path: "/account/address/edit/:id?",
    component: _bad8f4c0,
    name: "account-address-edit-id___he"
  }, {
    path: "/ar/blog/:slug",
    component: _0078f2c2,
    name: "blog-slug___ar"
  }, {
    path: "/ar/product/:slug?",
    component: _d10599d8,
    name: "product-slug___ar"
  }, {
    path: "/en/blog/:slug",
    component: _0078f2c2,
    name: "blog-slug___en"
  }, {
    path: "/en/product/:slug?",
    component: _d10599d8,
    name: "product-slug___en"
  }, {
    path: "/blog/:slug",
    component: _0078f2c2,
    name: "blog-slug___he"
  }, {
    path: "/product/:slug?",
    component: _d10599d8,
    name: "product-slug___he"
  }, {
    path: "/",
    component: _3914bf89,
    name: "index___he"
  }],

  fallback: false
}

function decodeObj(obj) {
  for (const key in obj) {
    if (typeof obj[key] === 'string') {
      obj[key] = decode(obj[key])
    }
  }
}

export function createRouter () {
  const router = new Router(routerOptions)

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    const r = resolve(to, current, append)
    if (r && r.resolved && r.resolved.query) {
      decodeObj(r.resolved.query)
    }
    return r
  }

  return router
}
